angular.module('app')
    .controller('LoginController', ['$scope', function($scope)
{
	// TODO: logUser function.
}]);








