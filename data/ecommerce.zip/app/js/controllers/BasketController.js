/** Basket view controller */
angular.module('app')
    .controller('BasketController', ['$scope', function($scope)
{
	$scope.items = []; // TODO
         
	$scope.getTotal = function() {
		 // TODO
		return 0;
	};
}]);