/** Profile view controller */
angular.module('app')
    .controller('ProfileController',['$scope',function($scope) {

	$scope.user = null; // TODO

	$scope.updateUser = function() {
		// TODO
	};
}]);