TrainingAngularJS
=================

This repo  contains the Lab project for the AngularJS Training.

See [got5/Angular-Libraries/angular-training](https://github.com/got5/Angular-Librairies/tree/master/angular-training)