/**
 * Created by pierremarot on 01/04/2014.
 */

describe("Detail Book Page", function () {

    beforeEach(function () {
        browser.get('http://localhost:3000/#/book/1');
    });
});