/**
 * Created by pierremarot on 03/09/13.
 */
describe("mySuite",function(){
    it("should be true" ,function(){
        expect(true).toBe(true);
    })
})
