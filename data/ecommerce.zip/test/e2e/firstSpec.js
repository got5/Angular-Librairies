/**
 * Created by pierremarot on 07/03/2014.
 */
describe('load page',function(){
    beforeEach(function(){
        browser.get('/');
    })
});